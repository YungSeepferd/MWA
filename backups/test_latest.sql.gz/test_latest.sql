BEGIN TRANSACTION;
CREATE TABLE backup_metadata (
	id INTEGER NOT NULL, 
	backup_type VARCHAR(50) NOT NULL, 
	backup_path VARCHAR(1000) NOT NULL, 
	backup_size_mb FLOAT, 
	created_at DATETIME NOT NULL, 
	completed_at DATETIME, 
	status VARCHAR(20) NOT NULL, 
	checksum VARCHAR(64), 
	metadata_info TEXT, 
	created_by VARCHAR(100), 
	PRIMARY KEY (id)
);
CREATE TABLE configuration (
	id INTEGER NOT NULL, 
	"key" VARCHAR(100) NOT NULL, 
	value TEXT NOT NULL, 
	description VARCHAR(500), 
	data_type VARCHAR(20) NOT NULL, 
	updated_at DATETIME NOT NULL, 
	updated_by VARCHAR(100), 
	PRIMARY KEY (id)
);
CREATE TABLE contact_validations (
	id INTEGER NOT NULL, 
	contact_id INTEGER NOT NULL, 
	validation_method VARCHAR(50) NOT NULL, 
	validation_result VARCHAR(11) NOT NULL, 
	confidence_score FLOAT, 
	validation_metadata TEXT, 
	validated_at DATETIME NOT NULL, 
	validator_version VARCHAR(20), 
	PRIMARY KEY (id), 
	FOREIGN KEY(contact_id) REFERENCES contacts (id)
);
CREATE TABLE contacts (
	id INTEGER NOT NULL, 
	listing_id INTEGER NOT NULL, 
	type VARCHAR(7) NOT NULL, 
	value VARCHAR(500) NOT NULL, 
	confidence FLOAT, 
	source VARCHAR(50), 
	status VARCHAR(11) NOT NULL, 
	validated_at DATETIME, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	hash_signature VARCHAR(64), 
	validation_metadata TEXT, 
	usage_count INTEGER NOT NULL, 
	last_used_at DATETIME, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_listing_contact UNIQUE (listing_id, type, value), 
	FOREIGN KEY(listing_id) REFERENCES listings (id)
);
CREATE TABLE job_store (
	id INTEGER NOT NULL, 
	job_id VARCHAR(100) NOT NULL, 
	job_name VARCHAR(200) NOT NULL, 
	job_type VARCHAR(50) NOT NULL, 
	job_data TEXT NOT NULL, 
	schedule_expression VARCHAR(100), 
	next_run_time DATETIME, 
	last_run_time DATETIME, 
	run_count INTEGER NOT NULL, 
	success_count INTEGER NOT NULL, 
	failure_count INTEGER NOT NULL, 
	enabled BOOLEAN NOT NULL, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id)
);
CREATE TABLE listing_scraping_runs (
	id INTEGER NOT NULL, 
	listing_id INTEGER NOT NULL, 
	scraping_run_id INTEGER NOT NULL, 
	discovered_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_listing_scraping_run UNIQUE (listing_id, scraping_run_id), 
	FOREIGN KEY(listing_id) REFERENCES listings (id), 
	FOREIGN KEY(scraping_run_id) REFERENCES scraping_runs (id)
);
CREATE TABLE listings (
	id INTEGER NOT NULL, 
	provider VARCHAR(50) NOT NULL, 
	external_id VARCHAR(100), 
	title VARCHAR(500) NOT NULL, 
	url VARCHAR(1000) NOT NULL, 
	price VARCHAR(50), 
	size VARCHAR(50), 
	rooms VARCHAR(20), 
	address VARCHAR(500), 
	description TEXT, 
	images TEXT, 
	contacts TEXT, 
	scraped_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	status VARCHAR(8) NOT NULL, 
	raw_data TEXT, 
	hash_signature VARCHAR(64), 
	deduplication_status VARCHAR(9) NOT NULL, 
	duplicate_of_id INTEGER, 
	first_seen_at DATETIME NOT NULL, 
	last_seen_at DATETIME NOT NULL, 
	view_count INTEGER NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_provider_external_id UNIQUE (provider, external_id), 
	FOREIGN KEY(duplicate_of_id) REFERENCES listings (id)
);
CREATE TABLE schema_migrations (
                        version VARCHAR(20) PRIMARY KEY,
                        applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    );
CREATE TABLE scraping_runs (
	id INTEGER NOT NULL, 
	provider VARCHAR(50) NOT NULL, 
	status VARCHAR(9) NOT NULL, 
	started_at DATETIME NOT NULL, 
	completed_at DATETIME, 
	listings_found INTEGER NOT NULL, 
	listings_processed INTEGER NOT NULL, 
	errors TEXT, 
	performance_metrics TEXT, 
	configuration_snapshot TEXT, 
	trigger_type VARCHAR(50), 
	triggered_by VARCHAR(100), 
	duration_seconds FLOAT, 
	memory_usage_mb FLOAT, 
	cpu_usage_percent FLOAT, 
	network_requests INTEGER NOT NULL, 
	data_size_mb FLOAT, 
	PRIMARY KEY (id)
);
CREATE INDEX idx_listings_hash_signature ON listings (hash_signature);
CREATE INDEX ix_listings_provider ON listings (provider);
CREATE UNIQUE INDEX ix_listings_hash_signature ON listings (hash_signature);
CREATE UNIQUE INDEX ix_listings_url ON listings (url);
CREATE INDEX idx_listings_scraped_at_desc ON listings (scraped_at);
CREATE INDEX ix_listings_deduplication_status ON listings (deduplication_status);
CREATE INDEX ix_listings_status ON listings (status);
CREATE INDEX ix_listings_scraped_at ON listings (scraped_at);
CREATE INDEX idx_listings_provider_status ON listings (provider, status);
CREATE INDEX ix_scraping_runs_started_at ON scraping_runs (started_at);
CREATE INDEX ix_scraping_runs_status ON scraping_runs (status);
CREATE INDEX idx_scraping_runs_started_at_desc ON scraping_runs (started_at);
CREATE INDEX ix_scraping_runs_provider ON scraping_runs (provider);
CREATE INDEX idx_scraping_runs_provider_status ON scraping_runs (provider, status);
CREATE INDEX idx_job_store_next_run_time ON job_store (next_run_time);
CREATE INDEX ix_job_store_job_type ON job_store (job_type);
CREATE INDEX idx_job_store_job_type_enabled ON job_store (job_type, enabled);
CREATE UNIQUE INDEX ix_job_store_job_id ON job_store (job_id);
CREATE INDEX ix_job_store_next_run_time ON job_store (next_run_time);
CREATE INDEX ix_job_store_enabled ON job_store (enabled);
CREATE INDEX idx_configuration_key ON configuration ("key");
CREATE UNIQUE INDEX ix_configuration_key ON configuration ("key");
CREATE INDEX ix_backup_metadata_created_at ON backup_metadata (created_at);
CREATE INDEX ix_backup_metadata_backup_type ON backup_metadata (backup_type);
CREATE INDEX idx_backup_metadata_created_at ON backup_metadata (created_at);
CREATE INDEX ix_contacts_hash_signature ON contacts (hash_signature);
CREATE INDEX ix_contacts_type ON contacts (type);
CREATE INDEX idx_contacts_status ON contacts (status);
CREATE INDEX idx_contacts_created_at ON contacts (created_at);
CREATE INDEX ix_contacts_status ON contacts (status);
CREATE INDEX ix_contacts_listing_id ON contacts (listing_id);
CREATE INDEX idx_contacts_listing_type ON contacts (listing_id, type);
CREATE INDEX ix_listing_scraping_runs_scraping_run_id ON listing_scraping_runs (scraping_run_id);
CREATE INDEX ix_listing_scraping_runs_listing_id ON listing_scraping_runs (listing_id);
CREATE INDEX idx_listing_scraping_runs_listing ON listing_scraping_runs (listing_id);
CREATE INDEX idx_listing_scraping_runs_scraping_run ON listing_scraping_runs (scraping_run_id);
CREATE INDEX ix_contact_validations_contact_id ON contact_validations (contact_id);
CREATE INDEX idx_contact_validations_contact ON contact_validations (contact_id);
CREATE INDEX idx_contact_validations_validated_at ON contact_validations (validated_at);
CREATE INDEX idx_listings_provider ON listings(provider);
CREATE INDEX idx_listings_status ON listings(status);
CREATE INDEX idx_listings_scraped_at ON listings(scraped_at);
CREATE INDEX idx_contacts_listing_id ON contacts(listing_id);
CREATE INDEX idx_contacts_type ON contacts(type);
CREATE INDEX idx_scraping_runs_provider ON scraping_runs(provider);
CREATE INDEX idx_scraping_runs_status ON scraping_runs(status);
CREATE INDEX idx_scraping_runs_started_at ON scraping_runs(started_at);
COMMIT;
